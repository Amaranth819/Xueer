# Android-CleanArchitecture

## Advantages of the systems

1. Independence of the framework

2. Testability

3. Independence of UI and database

4. Independence of external agency


## Key vocabularies

1. Entities

2. Use cases

3. Interface adapters

4. Frameworks and drivers

## Architecture

![clean_architecture_android](G:\TyporaProjects\xueer\Android Frameworks\images\clean_architecture_android.png)

### Attentions

1. Each layer uses its own data model.
2. Each layer works independently.
3. The architecture is MVP.

## Presenter Layer

![clean_architecture_mvp](G:\TyporaProjects\xueer\Android Frameworks\images\clean_architecture_mvp.png)



### Composition

**Interactors** that perform the job in **a new thread outside the main Android UI thread** and come back **using a callback** with the data that will be rendered in the view.

## Domain Layer

![clean_architecture_domain](G:\TyporaProjects\xueer\Android Frameworks\images\clean_architecture_domain.png)

### Attentions

1. All the logic happens in this layer.
2. No Android dependencies in this demo.

## Data Layer

![clean_architecture_data](G:\TyporaProjects\xueer\Android Frameworks\images\clean_architecture_data.png)

### Attentions

1. Picks different data in different situations.
2. All needed data comes from this layer through a UserRepository implementation ( the interface is in the domain layer ).
3. The idea is that the data origin is transparent for the clients.

## Advantages

1. Easy to maintain and test.
2. Very cohesive.
3. Decoupled.




# Agera

## 参考网站

1. https://github.com/google/agera

## 简介

超轻量级安卓开发库。

## 特点

1. 帮助安卓应用中有生命周期的组件或者组件中的对象预准备数据。
2. 函数式响应式编程。
3. 时机层面、数据层面、线程层面的数据分离处理流程.

## 适合场景

事件源比较集中，对数据的处理简单。

## 专有名词

1. Updatable：观察者。接收时间通知，更新数据。
2. Observable：被观察者、事件源。作为事件源，通知观察者更新数据，可以注册、注销观察者。
3. Supplier：数据提供者。用于获得新数据。
4. Repository：数据仓库。接收事件源、提供数据源的结合体。
5. Reactive programming：响应式编程。一种面向数据流和变化传播的编程范式。 这意味着在编程语言中很方便地表达静态或动态的数据流，而相关的计算模型会自动将变化的值通过数据流进行传播。
6. Activation lifecycle：激活生命周期。注册观察者时变为激活状态，注销观察者时变为非激活状态。
7. Active：激活状态。
8. Inactive：非激活状态。





# RxJava

## 参考网站

1. http://gank.io/post/560e15be2dca930e00da1083 —— 给 Android 开发者的 RxJava 详解

## 简介

轻量级Android开发框架。

## 关键词

1. 简洁
2. 扩展的观察者模式
3. 异步

## 观察者模式

OnClickListener的模式（一种专用的观察者模式，用于监听控件的点击事件）：

![52eb2279jw1f2rx42h1wgj20fz03rglt](G:\TyporaProjects\xueer\Android Frameworks\images\52eb2279jw1f2rx42h1wgj20fz03rglt.jpg)

抽象概念之后，得到通用的观察者模式：

![52eb2279jw1f2rx4446ldj20ga03p74h](G:\TyporaProjects\xueer\Android Frameworks\images\52eb2279jw1f2rx4446ldj20ga03p74h.jpg)

其中：

1. Button对应被观察者
2. onClickListener对应观察者
3. onClick()对应事件
4. setOnClickListener()对应订阅



## RxJava的观察者模式

四个**基本概念**：Observable(可观察者，即被观察者)、Observer(观察者)、Subscribe(订阅)、事件。

Observable 和Observer通过Subscribe()方法实现订阅关系，从而Observable可以在需要的时候发出事件来通知Observer。

两个**特殊事件**：onCompleted()（事件队列完结）和onError()（事件队列异常）。



RxJava的观察者模式图：

![52eb2279jw1f2rx46dspqj20gn04qaad](G:\TyporaProjects\xueer\Android Frameworks\images\52eb2279jw1f2rx46dspqj20gn04qaad.jpg)



## RxJava线程控制——Scheduler

### 简介

线程调度器，RxJava通过Scheduler来指定执行某一段代码的线程。

### 特点

1. 允许事件和消费发生在不同的线程，并且可以实现线程的自由、多次切换。因为observeOn()函数所操作的线程是当前的Observable所对应的Subscriber，即指定的是它之后的操作所在的线程（所以可以在需要改变线程的位置多次调用该函数）。

![ObserveOn](G:\TyporaProjects\xueer\Android Frameworks\images\ObserveOn.jpg)

2. SubscribeOn()函数只能被调用一次。

![SubscribeOn](G:\TyporaProjects\xueer\Android Frameworks\images\SubscribeOn.jpg)







## 变换

### 简介

可以针对事件对象和事件队列，直接变换对象的类型。

### 变换函数

1. map()：事件对象的直接变换。
2. flatMap()：一对多对象的变换。
3. lift(operator)：最基础的变换方法，派生了许多其他的变换。变换的本质是**针对时间序列的处理和再发送**。对该函数功能的简要概括：在Observable执行了lift()方法后会返回一个全新的Observable，这个新的Observable的作用类似代理，负责接收原始的Observable发出的事件，并在处理后发送给Subscriber，即类似代理机制，通过事件拦截和处理实现事件序列的变换。

![52eb2279jw1f2rxcrna27j20h40d1q4f](G:\TyporaProjects\xueer\Android Frameworks\images\52eb2279jw1f2rxcrna27j20h40d1q4f.jpg)

4. compose()：**针对Observable自身**进行变换。








# AndBase

参考网站：https://github.com/CraftsmenTech/AndBase

包含功能：

1. 网络工具包、线程、数据库、图片处理工具等
2. 控件
3. 图片缓存管理策略，减少内存开销
4. 异步网络请求



# XUtils

参考网站：https://github.com/wyouflf/xUtils3 （3.x版本）https://github.com/wyouflf/xUtils （2.x版本）

主要功能：

1. 超大文件上传
2. 事件注解支持
3. 图片绑定支持
4. http请求支持协议





# ThinkAndroid

参考网站：https://github.com/white-cat/ThinkAndroid

架构：MVC

特点：

1. 快速构建文件缓存（任意文件类型）
2. 包含一个开发工具类，功能包括日志管理，配置文件管理，android下载器模块，网络切换检测等等。





# Android-async-http

参考网站：https://github.com/loopj/android-async-http

主要功能：

1. 在匿名回调中处理请求结果
2. 在UI线程外进行http请求
3. 文件断点上传
4. 智能重试
5. 默认gzip压缩
6. 支持解析成Json格式
7. 可将Cookies持久化到SharedPreferences






## MVVM框架图例

![MVVMPattern](G:\TyporaProjects\DataBindingSample\images\MVVMPattern.png)





## 亚马逊架构设计图

#### 网络层次架构与通信

![9f6114a74250b88a4185f47fc911a333_hd](G:\TyporaProjects\xueer\Android Frameworks\images\9f6114a74250b88a4185f47fc911a333_hd.jpg)

组成部分：

1. 防火墙
2. 服务器端，包括数据库服务器、网络服务器、应用服务器。
3. EBS：持久性块存储卷

#### 物理架构图

![9da2e4313cc160a3c347f1474a38bec5_hd](G:\TyporaProjects\xueer\Android Frameworks\images\9da2e4313cc160a3c347f1474a38bec5_hd.jpg)





## 架构的种类

1. 业务（逻辑）架构：对所项目所涉及到的需求的业务进行业务边界划分，不需要考虑到软硬件方面的具体实现。
2. 应用架构：介于业务语言和技术语言之间，是对系统实现的整体上的架构，需要指出系统层次及其应用服务、开发原则等。
3. 数据（持久化）架构：对存储数据的架构方法论。
4. 技术架构：涉及具体的技术方案的语言层次实现。







